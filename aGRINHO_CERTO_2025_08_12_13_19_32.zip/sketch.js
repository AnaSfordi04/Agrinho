function setup() {
 createCanvas(400, 400);

}  

let xJogador = [0, 0, 0, 0];
let yJogador = [75, 150, 225, 300];
let jogador = ["👩‍🌾", "🚜", "🤖", "🐎"];
let teclas = ["a", "s", "d", "f"];
let quantidade = jogador.length; 

function draw() {
  ativaJogo();
  desenhaJogadores();
  desenhaLinhaDeChegada();
  verificaVencedor();
}

function ativaJogo() {
  if (focused == true) {
    background("#FFFFFF");
  } else {
    background("#000000");
    textSize(10)
    text("cada jogador deve escolher um emoji, vence quem tiver a melhor tecnologia;",10,20)
    text("primeiro, clique na tela;",20,40)
    text("o jogador 1 deve apertar a tecla A",40,60)
    text("o jogador 2 deve apertar a tecla S",40,80)
    text("o jogador 3 deve apertar a tecla D",40,100)
    text("o jogador 4 deve apertar a tecla F",40,120)
    text("Quem chegar primeiro vence!",45,140)
  }
}

function desenhaJogadores() {
  textSize(10);
  for (let i = 0; i < quantidade; i++) {
    text(jogador[i], xJogador[i], yJogador[i]);
  }
}

function desenhaLinhaDeChegada() {
  fill("#9A71E4");
  rect(350, 0, 10, 400);
  fill("#6FA0C7");
  for (let yAtual = 0; yAtual < 400; yAtual += 20) {
    rect(350, yAtual, 10, 10);
  }
}

function verificaVencedor() {
  for (let i = 0; i < quantidade; i++) {
    if (xJogador[i] > 350) {
      text(jogador[i] + " venceu! Sua tecnologia é a melhor.", 50, 200);
      noLoop();
    }
  }
}

function keyReleased() {
  for (let i = 0; i < quantidade; i++) {
    if (key == teclas[i]) {
      xJogador[i] += random(20);
    }
  }
}